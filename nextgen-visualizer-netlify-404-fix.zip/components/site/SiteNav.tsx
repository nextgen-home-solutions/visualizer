import Link from "next/link";

export default function SiteNav() {
  return (
    <header className="siteHeader">
      <div className="siteHeaderInner">
        <Link href="/" className="siteBrand" aria-label="NEXTGEN home solutions home">
          <img className="siteLogo" src="/nextgen-logo.png" alt="NEXTGEN home solutions" />
        </Link>

        <nav className="siteNav">
          <Link href="/services" className="siteNavLink">Services</Link>
          <Link href="/portfolio" className="siteNavLink">Portfolio</Link>
          <Link href="/process" className="siteNavLink">Process</Link>
          <Link href="/financing" className="siteNavLink">Financing</Link>
          <Link href="/contact" className="siteNavLink">Contact</Link>
        </nav>

        <div className="siteHeaderCtas">
          <Link href="/visualizer" className="btn">Try Visualizer</Link>
          <a href="mailto:homesolutions@nextgen-ne.com" className="btn primary">Email Us</a>
        </div>
      </div>
    </header>
  );
}
