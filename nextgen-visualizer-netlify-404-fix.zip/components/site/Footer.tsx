import Link from "next/link";

export default function Footer() {
  return (
    <footer className="siteFooter">
      <div className="siteFooterInner">
        <div className="footerLeft">
          <img className="footerLogo" src="/nextgen-logo.png" alt="NEXTGEN home solutions" />
          <p className="muted">
            Redefining home improvement across Massachusetts. Design-forward remodeling with transparent planning,
            quality craftsmanship, and premium finishes.
          </p>
        </div>

        <div className="footerCols">
          <div className="footerCol">
            <div className="footerTitle">Explore</div>
            <Link href="/services" className="footerLink">Services</Link>
            <Link href="/portfolio" className="footerLink">Portfolio</Link>
            <Link href="/process" className="footerLink">Our process</Link>
            <Link href="/visualizer" className="footerLink">NextGen Visualizer</Link>
          </div>
          <div className="footerCol">
            <div className="footerTitle">Company</div>
            <Link href="/about" className="footerLink">About</Link>
            <Link href="/contact" className="footerLink">Contact</Link>
            <a className="footerLink" href="mailto:homesolutions@nextgen-ne.com">Email</a>
            <a className="footerLink" href="tel:+18889598014">Call / Text: 888-959-8014</a>
            <a className="footerLink" href="mailto:homesolutions@nextgen-ne.com">Email</a>
            <a className="footerLink" href="tel:+18889598014">Call / Text: 888-959-8014</a>
          </div>
          <div className="footerCol">
            <div className="footerTitle">Service areas</div>
            <div className="muted">Greater Boston</div>
            <div className="muted">Worcester County</div>
            <div className="muted">Middlesex County</div>
            <div className="muted">Norfolk County</div>
          </div>
        </div>
      </div>

      <div className="siteFooterBottom">
        <span>© {new Date().getFullYear()} NEXTGEN home solutions</span>
        <span className="muted">REDEFINING HOME IMPROVEMENT</span>
      </div>
    </footer>
  );
}
