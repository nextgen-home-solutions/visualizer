import Link from "next/link";
import SiteNav from "../../components/site/SiteNav";
import Footer from "../../components/site/Footer";
import Section from "../../components/site/Section";

export default function ProcessPage() {
  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />
      <main className="siteMain">
        <section className="pageHero">
          <div className="pageHeroInner">
            <h1 className="h1">Our process</h1>
            <p className="lead">A premium experience built on clarity, speed, and craftsmanship.</p>
            <div className="heroCtas">
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
              <Link className="btn" href="/visualizer">Try Visualizer</Link>
            </div>
          </div>
        </section>

        <Section title="How we run projects" subtitle="We keep the process simple, professional, and predictable.">
          <div className="steps">
            {[
              ["1) Discovery + goals", "We understand your goals, style preferences, and constraints (timeline, budget, layout)."],
              ["2) Concept + options", "We show finish options and functional improvements clients often overlook."],
              ["3) Estimate + schedule", "Line items, timeline, and trade sequencing — then confirm onsite measurements."],
              ["4) Build + daily communication", "Clear milestones, jobsite protection, and fast issue resolution."],
              ["5) Punch list + warranty", "Final walkthrough and warranty support so you feel confident long-term."],
            ].map(([t, d]) => (
              <div className="step" key={t}>
                <div className="stepTitle">{t}</div>
                <p className="muted">{d}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Try it first" subtitle="Use NextGen Visualizer to generate a concept image and attach it to your quote request.">
          <div className="centerRow">
            <Link className="btn primary" href="/visualizer">Launch Visualizer</Link>
            <Link className="btn" href="/contact">Request quote</Link>
          </div>
        </Section>
      </main>
      <Footer />
    </div>
  );
}
