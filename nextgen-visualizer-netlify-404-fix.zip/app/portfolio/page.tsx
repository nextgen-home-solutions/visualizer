import Link from "next/link";
import SiteNav from "../../components/site/SiteNav";
import Footer from "../../components/site/Footer";
import Section from "../../components/site/Section";

export default function PortfolioPage() {
  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />
      <main className="siteMain">
        <section className="pageHero">
          <div className="pageHeroInner">
            <h1 className="h1">Portfolio</h1>
            <p className="lead">A few of the styles we love — modern, transitional, contemporary, and classic.</p>
            <div className="heroCtas">
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
              <Link className="btn" href="/visualizer">Visualize yours</Link>
            </div>
          </div>
        </section>

        <Section title="Project gallery" subtitle="Replace these placeholders with your real project photos anytime (drop them into /public/portfolio).">
          <div className="galleryGrid">
            {Array.from({ length: 12 }).map((_, i) => (
              <div className="galleryTile" key={i}>
                <div className="galleryOverlay">
                  <div className="galleryTitle">Kitchen remodel</div>
                  <div className="muted">Cabinets • counters • lighting</div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        <section className="ctaBand">
          <div className="ctaBandInner">
            <div>
              <div className="ctaTitle">Want a concept for your space?</div>
              <div className="muted">Upload a photo and generate your remodel idea in minutes.</div>
            </div>
            <div className="ctaBtns">
              <Link className="btn primary" href="/visualizer">Try Visualizer</Link>
              <Link className="btn" href="/contact">Get a Quote</Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
