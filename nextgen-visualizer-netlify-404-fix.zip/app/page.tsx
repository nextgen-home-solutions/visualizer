import Link from "next/link";
import SiteNav from "../components/site/SiteNav";
import Footer from "../components/site/Footer";
import Section from "../components/site/Section";

export default function HomePage() {
  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />

      <main className="siteMain">
        <section className="hero">
          <div className="heroInner">
            <div className="heroContent">
              <div className="badgeRow">
                <span className="badge">Massachusetts Remodeling</span>
                <span className="badge">Design + Build</span>
                <span className="badge">Licensed & Insured</span>
              </div>

              <h1 className="h1">
                Premium remodeling for kitchens, baths, basements, and full-home transformations.
              </h1>
              <p className="lead">
                NEXTGEN home solutions delivers end-to-end design, material selection, and craftsmanship —
                plus an AI visualizer so you can see your remodel before you commit.
              </p>

              <div className="heroCtas">
                <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
                <Link className="btn" href="/visualizer">Try NextGen Visualizer</Link>
              </div>

              <div className="trustRow">
                <div className="trustCard">
                  <div className="trustNum">48–72h</div>
                  <div className="trustLabel">Concept + ballpark estimate</div>
                </div>
                <div className="trustCard">
                  <div className="trustNum">MA rates</div>
                  <div className="trustLabel">Trade pricing + labor ranges</div>
                </div>
                <div className="trustCard">
                  <div className="trustNum">Quality-first</div>
                  <div className="trustLabel">Craftsmanship & warranty</div>
                </div>
              </div>
            </div>

            <div className="heroShowcase">
              <div className="glassCard">
                <div className="glassTitle">NextGen Visualizer</div>
                <p className="muted">
                  Upload a room photo → describe your dream finish → generate a realistic remodel concept.
                </p>
                <div className="miniSteps">
                  <div className="miniStep"><span className="dot" /> Upload photos</div>
                  <div className="miniStep"><span className="dot" /> Choose style + materials</div>
                  <div className="miniStep"><span className="dot" /> Get estimate</div>
                </div>
                <Link className="btn primary" href="/visualizer">Launch Visualizer</Link>
                <div className="muted" style={{ marginTop: 10, fontSize: 12 }}>
                  Tip: For best results, use bright lighting and keep the camera level.
                </div>
              </div>
            </div>
          </div>
        </section>

        <Section
          eyebrow="Services"
          title="Everything you need for a high-end remodel"
          subtitle="Design guidance, sourcing, permitting support, and skilled execution — all in one place."
        >
          <div className="grid3">
            {[
              ["Kitchen remodeling", "Cabinets, counters, layouts, lighting, flooring, islands, and premium details."],
              ["Bathroom remodeling", "Showers, tile, vanities, plumbing fixtures, ventilation, and waterproofing."],
              ["Basements + ADUs", "Finish basements, build livable suites, and add functional square footage."],
              ["Flooring + paint", "LVP/hardwood/tile installs, prep, trim, and interior/exterior paint."],
              ["Exterior upgrades", "Siding, windows, doors, decks, and curb-appeal improvements."],
              ["Full-home renovation", "A coordinated plan for whole-house updates and value-boosting improvements."],
            ].map(([t, d]) => (
              <div className="featureCard" key={t}>
                <div className="featureTitle">{t}</div>
                <p className="muted">{d}</p>
              </div>
            ))}
          </div>

          <div className="centerRow">
            <Link className="btn" href="/services">View all services</Link>
            <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
          </div>
        </Section>

        <Section
          eyebrow="Portfolio"
          title="Modern finishes. Timeless execution."
          subtitle="A curated look at the styles we deliver — transitional, modern, contemporary, and classic."
        >
          <div className="galleryGrid">
            {Array.from({ length: 6 }).map((_, i) => (
              <div className="galleryTile" key={i}>
                <div className="galleryOverlay">
                  <div className="galleryTitle">Project highlight</div>
                  <div className="muted">Quartz • shaker • matte black</div>
                </div>
              </div>
            ))}
          </div>

          <div className="centerRow">
            <Link className="btn" href="/portfolio">See more work</Link>
            <Link className="btn primary" href="/visualizer">Visualize yours</Link>
          </div>
        </Section>

        <Section
          eyebrow="Our process"
          title="Clarity, speed, and craftsmanship"
          subtitle="A premium experience — from first concept to final walkthrough."
        >
          <div className="steps">
            {[
              ["1) Visualize + scope", "Upload photos, select finishes, and tell us what you want. We'll clarify constraints and options."],
              ["2) Estimate + plan", "We create a line-item estimate and timeline, then confirm site conditions with a consult if needed."],
              ["3) Build + communicate", "Daily updates, milestone check-ins, and clean job sites. We treat your home like it's ours."],
              ["4) Deliver + warranty", "Final punch list, walkthrough, and warranty support — built for long-term confidence."],
            ].map(([t, d]) => (
              <div className="step" key={t}>
                <div className="stepTitle">{t}</div>
                <p className="muted">{d}</p>
              </div>
            ))}
          </div>

          <div className="centerRow">
            <Link className="btn" href="/process">Learn our process</Link>
            <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
          </div>
        </Section>

        <section className="ctaBand">
          <div className="ctaBandInner">
            <div>
              <div className="ctaTitle">Ready to start?</div>
              <div className="muted">
                Get a quote, see design options, and build a plan that fits your timeline.
              </div>
            </div>
            <div className="ctaBtns">
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
              <Link className="btn" href="/visualizer">Try Visualizer</Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
