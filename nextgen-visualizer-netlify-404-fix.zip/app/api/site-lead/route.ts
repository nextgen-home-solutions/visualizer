import { NextResponse } from "next/server";
import { supabaseServer } from "../../../lib/supabase";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const payload = {
      name: String(body?.name || "").trim(),
      email: String(body?.email || "").trim(),
      phone: String(body?.phone || "").trim(),
      address: String(body?.address || "").trim(),
      message: String(body?.message || "").trim(),
      page: String(body?.page || "").trim(),
      created_at: new Date().toISOString(),
    };

    if (!payload.name || (!payload.email && !payload.phone)) {
      return NextResponse.json({ error: "Please include a name and at least an email or phone." }, { status: 400 });
    }

    const sb = supabaseServer();
    const { error } = await sb.from("nextgen_site_leads").insert(payload);
    if (error) {
      return NextResponse.json({ error: "Failed to save lead", details: error.message }, { status: 500 });
    }

    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: "Bad request", details: e?.message ?? String(e) }, { status: 400 });
  }
}
