import Link from "next/link";
import SiteNav from "../../components/site/SiteNav";
import Footer from "../../components/site/Footer";
import Section from "../../components/site/Section";

const SERVICES = [
  { title: "Kitchen remodeling", bullets: ["Layout + islands", "Cabinets + hardware", "Quartz / granite counters", "Lighting plan", "Flooring + paint"] },
  { title: "Bathroom remodeling", bullets: ["Showers + tile", "Vanities + tops", "Fixtures + plumbing", "Ventilation", "Waterproofing"] },
  { title: "Basements + ADUs", bullets: ["Framing + insulation", "Drywall + paint", "Flooring", "Bathrooms/kitchenettes", "Egress planning"] },
  { title: "Flooring + interior paint", bullets: ["Hardwood/LVP/tile", "Subfloor prep", "Trim + finish carpentry", "Whole-home paint", "Clean lines + protection"] },
  { title: "Exterior upgrades", bullets: ["Siding + repairs", "Windows + doors", "Decks + railings", "Curb appeal refresh", "Weather sealing"] },
  { title: "Full-home renovation", bullets: ["Phased planning", "Material sourcing", "Permit coordination", "Multi-room execution", "Final punch + warranty"] },
];

export default function ServicesPage() {
  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />
      <main className="siteMain">
        <section className="pageHero">
          <div className="pageHeroInner">
            <h1 className="h1">Services</h1>
            <p className="lead">Premium craftsmanship with design-forward options and clear communication.</p>
            <div className="heroCtas">
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
              <Link className="btn" href="/visualizer">Try Visualizer</Link>
            </div>
          </div>
        </section>

        <Section title="What we do" subtitle="From small upgrades to full-home transformations.">
          <div className="grid3">
            {SERVICES.map(s => (
              <div className="featureCard" key={s.title}>
                <div className="featureTitle">{s.title}</div>
                <ul className="bullets">
                  {s.bullets.map(b => <li key={b}>{b}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Massachusetts-focused estimating" subtitle="We build estimates using realistic MA labor ranges and material categories.">
          <div className="callout">
            <div className="calloutTitle">Want to see options first?</div>
            <div className="muted">
              Use NextGen Visualizer to generate a concept image and attach it when you request a quote.
            </div>
            <div className="centerRow">
              <Link className="btn primary" href="/visualizer">Launch Visualizer</Link>
              <Link className="btn" href="/contact">Request quote</Link>
            </div>
          </div>
        </Section>
      </main>
      <Footer />
    </div>
  );
}
