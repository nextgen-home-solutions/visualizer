import Link from "next/link";
import SiteNav from "../../components/site/SiteNav";
import Footer from "../../components/site/Footer";
import Section from "../../components/site/Section";

export default function FinancingPage() {
  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />
      <main className="siteMain">
        <section className="pageHero">
          <div className="pageHeroInner">
            <h1 className="h1">Financing</h1>
            <p className="lead">We can help you plan a remodel that fits your timeline and monthly comfort level.</p>
            <div className="heroCtas">
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email about financing</a>
              <Link className="btn" href="/visualizer">Visualize your remodel</Link>
            </div>
          </div>
        </section>

        <Section title="Simple ways to plan" subtitle="These are common approaches homeowners use — we’ll guide you based on project size and scope.">
          <div className="grid3">
            {[
              ["Phased build", "Split work into phases (kitchen now, flooring/paint later) to spread cost and disruption."],
              ["Material tiers", "Choose a finish tier (good/better/best) so you can control total spend."],
              ["Design-first", "Finalize design and scope early to avoid surprises and protect your budget."],
            ].map(([t, d]) => (
              <div className="featureCard" key={t}>
                <div className="featureTitle">{t}</div>
                <p className="muted">{d}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Get a plan" subtitle="Share your goals and we’ll suggest scope options and an estimate range.">
          <div className="centerRow">
            <Link className="btn primary" href="/contact">Talk to us</Link>
            <Link className="btn" href="/visualizer">Try Visualizer</Link>
          </div>
        </Section>
      </main>
      <Footer />
    </div>
  );
}
