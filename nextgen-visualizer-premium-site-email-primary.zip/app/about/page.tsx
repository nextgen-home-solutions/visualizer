import Link from "next/link";
import SiteNav from "../../components/site/SiteNav";
import Footer from "../../components/site/Footer";
import Section from "../../components/site/Section";

export default function AboutPage() {
  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />
      <main className="siteMain">
        <section className="pageHero">
          <div className="pageHeroInner">
            <h1 className="h1">About NEXTGEN</h1>
            <p className="lead">REDEFINING HOME IMPROVEMENT — with a modern process and premium results.</p>
            <div className="heroCtas">
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
              <Link className="btn" href="/visualizer">Try Visualizer</Link>
            </div>
          </div>
        </section>

        <Section title="What we believe" subtitle="Quality and clarity should be the default — not the upgrade.">
          <div className="grid3">
            {[
              ["Design-forward", "We help you choose finishes that look cohesive, current, and timeless."],
              ["Transparent planning", "Scope, line items, and expectations are clear before we begin."],
              ["Craftsmanship", "The details matter — clean lines, solid prep, and durable installs."],
            ].map(([t, d]) => (
              <div className="featureCard" key={t}>
                <div className="featureTitle">{t}</div>
                <p className="muted">{d}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Want to see a concept image?" subtitle="Upload a photo and generate a remodel vision in minutes.">
          <div className="centerRow">
            <Link className="btn primary" href="/visualizer">Launch Visualizer</Link>
            <Link className="btn" href="/contact">Request quote</Link>
          </div>
        </Section>
      </main>
      <Footer />
    </div>
  );
}
