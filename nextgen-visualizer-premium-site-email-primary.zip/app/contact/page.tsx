"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import SiteNav from "../../components/site/SiteNav";
import Footer from "../../components/site/Footer";

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const canSubmit = useMemo(() => {
    return !!name.trim() && (!!email.trim() || !!phone.trim()) && !busy;
  }, [name, email, phone, busy]);

  async function submit() {
    setErr(null);
    setBusy(true);
    try {
      const r = await fetch("/api/site-lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          address: address.trim(),
          message: message.trim(),
          page: "/contact",
        }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data?.error || "Failed to submit");
      setDone(true);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to submit");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="siteShell">
      <div className="siteBg" aria-hidden="true" />
      <SiteNav />
      <main className="siteMain">
        <section className="pageHero">
          <div className="pageHeroInner">
            <h1 className="h1">Get a quote</h1>
            <p className="lead">Tell us what you want to remodel — we’ll respond quickly with next steps.</p>
            <div className="heroCtas">
              <Link className="btn" href="/visualizer">Try Visualizer</Link>
              <a className="btn primary" href="mailto:homesolutions@nextgen-ne.com">Email Us</a>
            </div>
          </div>
        </section>

        <section className="contactGrid">
          <div className="glassCard">
            <div className="glassTitle">Contact details</div>
            <p className="muted">Prefer to reach us directly?</p>
            <div className="contactRow">
              <div className="contactLabel">Email</div>
              <a className="contactValue" href="mailto:homesolutions@nextgen-ne.com">homesolutions@nextgen-ne.com</a>
            </div>
            <div className="contactRow">
              <div className="contactLabel">Phone</div>
              <a className="contactValue" href="tel:+18889598014">888-959-8014</a>
            </div>
            <div className="contactRow">
              <div className="contactLabel">Service area</div>
              <div className="contactValue">Massachusetts</div>
            </div>
            <div className="hr" />
            <div className="muted" style={{ fontSize: 12 }}>
              Tip: Upload a photo and generate a concept first — it makes estimating faster.
            </div>
            <div style={{ marginTop: 10 }}>
              <Link className="btn primary" href="/visualizer">Launch Visualizer</Link>
            </div>
          </div>

          <div className="panel">
            <div className="panelHeader">
              <div className="row">
                <span className="pill">Quote request</span>
                <span className="pill">48–72h response</span>
              </div>
            </div>
            <div className="panelBody">
              {done ? (
                <div>
                  <div className="featureTitle">Thanks — we got it.</div>
                  <p className="muted">We’ll reach out shortly. If you want, try the Visualizer while you wait.</p>
                  <div className="centerRow">
                    <Link className="btn primary" href="/visualizer">Try Visualizer</Link>
                    <Link className="btn" href="/">Back home</Link>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="grid2">
                    <div>
                      <div className="label">Name*</div>
                      <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
                    </div>
                    <div>
                      <div className="label">Email</div>
                      <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" />
                    </div>
                    <div>
                      <div className="label">Phone</div>
                      <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(555) 555-5555" />
                    </div>
                    <div>
                      <div className="label">Address / City</div>
                      <input className="input" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="City, MA" />
                    </div>
                  </div>

                  <div style={{ marginTop: 10 }}>
                    <div className="label">What are you remodeling?</div>
                    <textarea className="textarea" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Kitchen remodel, shaker cabinets, quartz counters, brighter lighting..." />
                  </div>

                  {err ? <div className="small" style={{ marginTop: 10, opacity: 0.95 }}>Error: {err}</div> : null}

                  <div style={{ marginTop: 12 }} className="row">
                    <button className="btn primary" onClick={submit} disabled={!canSubmit}>
                      {busy ? "Sending..." : "Submit"}
                    </button>
                    <span className="small">*Required. Email or phone required.</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
