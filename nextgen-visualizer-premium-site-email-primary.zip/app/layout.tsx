import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NEXTGEN home solutions | Redefining Home Improvement",
  description:
    "Premium remodeling in Massachusetts — kitchens, bathrooms, basements, and full-home renovations. Try the NextGen Visualizer to see your remodel before you build.",
  openGraph: {
    title: "NEXTGEN home solutions",
    description:
      "Premium remodeling in Massachusetts. Visualize your remodel and get a quote.",
    images: [{ url: "/og.svg" }],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NEXTGEN home solutions",
    description:
      "Premium remodeling in Massachusetts. Visualize your remodel and get a quote.",
    images: ["/og.svg"],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {/* Visualizer background layer (kept subtle). Site pages add their own premium background. */}
        <div className="bgHero" />
        {children}
      </body>
    </html>
  );
}
