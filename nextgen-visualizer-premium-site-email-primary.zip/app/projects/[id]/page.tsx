"use client";

import React, { useEffect, useMemo, useState } from "react";

export default function ProjectDetailPage({ params }: { params: { id: string } }) {
  const [p, setP] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    setErr(null);
    try {
      const r = await fetch(`/api/projects/${params.id}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d?.error || "Failed to load");
      setP(d);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to load");
    }
  }

  useEffect(() => { load(); }, []);

  const hero = useMemo(() => {
    const img = p?.renders?.[0]?.imageDataUrl || p?.images?.[0] || null;
    return img;
  }, [p]);

  return (
    <div style={{ minHeight: "100vh", padding: 22, background: "#0b1020", color: "#f9fafb", fontFamily: "ui-sans-serif, system-ui" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", maxWidth: 1100, margin: "0 auto" }}>
        <a href="/" style={{ textDecoration: "none", color: "inherit" }}>
          <img src="/nextgen-logo.png" style={{ width: 240 }} />
        </a>
        <div style={{ display: "flex", gap: 10 }}>
          <a href="/projects" style={{ padding: "10px 14px", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, textDecoration: "none" }}>All projects</a>
          <a href="/" style={{ padding: "10px 14px", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, textDecoration: "none" }}>Back</a>
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "18px auto 0" }}>
        {err ? <div style={{ fontSize: 12, opacity: 0.85 }}>Error: {err}</div> : null}
        {!p ? (
          <div style={{ fontSize: 12, opacity: 0.75 }}>Loading...</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1.1fr 0.9fr", gap: 16 }}>
            <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 16, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
              <div style={{ padding: 14, borderBottom: "1px solid rgba(255,255,255,0.12)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ fontSize: 14 }}>Project visualization</div>
                <div style={{ fontSize: 12, opacity: 0.7 }}>ID: {p.id}</div>
              </div>
              <div style={{ padding: 14 }}>
                {hero ? (
                  <img src={hero} style={{ width: "100%", borderRadius: 14, border: "1px solid rgba(255,255,255,0.12)" }} />
                ) : (
                  <div style={{ fontSize: 12, opacity: 0.75 }}>No image saved.</div>
                )}
              </div>
            </div>

            <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 16, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
              <div style={{ padding: 14, borderBottom: "1px solid rgba(255,255,255,0.12)" }}>
                <div style={{ fontSize: 14 }}>Details</div>
                <div style={{ fontSize: 12, opacity: 0.7 }}>
                  Updated: {new Date(p.updatedAt).toLocaleString()}
                </div>
              </div>
              <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
                <div style={{ fontSize: 12, opacity: 0.85 }}>
                  <b>{p.projectType}</b> • {p.style} • {p.quality} • {p.roomSizeSqft} sqft
                </div>

                <div style={{ fontSize: 12, opacity: 0.75, whiteSpace: "pre-wrap" }}>
                  {p.description || "—"}
                </div>

                {p.estimate?.range ? (
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <span style={{ padding: "6px 10px", borderRadius: 999, border: "1px solid rgba(255,255,255,0.12)" }}>Low: ${p.estimate.range.low.toLocaleString()}</span>
                    <span style={{ padding: "6px 10px", borderRadius: 999, border: "1px solid rgba(255,255,255,0.12)" }}>High: ${p.estimate.range.high.toLocaleString()}</span>
                  </div>
                ) : null}

                <div style={{ borderTop: "1px solid rgba(255,255,255,0.12)", paddingTop: 10 }}>
                  <div style={{ fontSize: 13, marginBottom: 6 }}>Book a consult</div>
                  <a
                    href="https://calendly.com/"
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      display: "inline-block",
                      padding: "10px 14px",
                      border: "1px solid rgba(96,165,250,0.35)",
                      background: "rgba(96,165,250,0.18)",
                      borderRadius: 12,
                      textDecoration: "none",
                      color: "inherit"
                    }}
                  >
                    Schedule a call
                  </a>
                  <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
                    Replace this link with your real scheduler (Calendly, Acuity, etc.).
                  </div>
                </div>

              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
