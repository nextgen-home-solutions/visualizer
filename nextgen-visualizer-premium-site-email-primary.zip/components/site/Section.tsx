export default function Section({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  return (
    <section className="siteSection">
      <div className="siteSectionHead">
        {eyebrow ? <div className="eyebrow">{eyebrow}</div> : null}
        <h2 className="h2">{title}</h2>
        {subtitle ? <p className="lead">{subtitle}</p> : null}
      </div>
      {children ? <div className="siteSectionBody">{children}</div> : null}
    </section>
  );
}
