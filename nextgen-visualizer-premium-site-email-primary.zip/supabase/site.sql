-- Website leads table (run once in Supabase SQL editor)
create table if not exists public.nextgen_site_leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text,
  phone text,
  address text,
  message text,
  page text
);

create index if not exists idx_nextgen_site_leads_created_at
  on public.nextgen_site_leads (created_at desc);
